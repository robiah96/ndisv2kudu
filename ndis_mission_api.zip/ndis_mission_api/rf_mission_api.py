from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import json
import pandas as pd
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles


# Initialize app
app = FastAPI(title="Drone-Sensor Mission Recommender API")

# Load assets once
model = joblib.load("rf_mission_model.joblib")
encoder = joblib.load("rf_label_encoder.joblib")

app.mount("/static", StaticFiles(directory="templates"), name="static")

@app.get("/form", response_class=HTMLResponse)
def serve_form():
    with open("templates/form.html", "r", encoding="utf-8") as f:
        return f.read()


with open("rf_features.json") as f:
    FEATURES = json.load(f)

# Input model for validation
class MissionRequest(BaseModel):
    HazardType: int
    distance: float
    pop: float
    intensity: float
    duration_minutes: float
    economic_loss_million: float
    sensor_weight: float
    drone_speed: float
    drone_flight_time: float

@app.post("/recommend")
def recommend_mission(input_data: MissionRequest):
    try:
        print("🔹 Input received:", input_data.dict())
        df = pd.DataFrame([input_data.dict()])[FEATURES]
        print("🔹 DataFrame:", df)

        pred_class = model.predict(df)[0]
        pred_label = encoder.inverse_transform([pred_class])[0]

        return {
            "recommended_drone_sensor_combo": pred_label,
            "input_summary": input_data.dict()
        }
    except Exception as e:
        print("❌ ERROR:", e)
        return {"error": str(e)}

# Only needed for local development
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
